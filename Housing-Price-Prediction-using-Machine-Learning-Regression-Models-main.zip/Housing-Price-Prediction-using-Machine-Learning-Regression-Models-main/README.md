# Housing-Price-Prediction-using-Machine-Learning-Regression-Models
◦ Conducted EDA on open-source data, including feature extraction and selection to reduce overfitting ◦ Trained models Linear, Logistic, and RF Regression, achieving 86% accuracy with Linear Regression ◦ Deployed the model with Flask for real-time housing price predictions via an API
